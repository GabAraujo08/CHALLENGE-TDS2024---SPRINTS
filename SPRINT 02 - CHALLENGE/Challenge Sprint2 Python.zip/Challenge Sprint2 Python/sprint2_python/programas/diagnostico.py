# Prototipo do diagnostico

# Nao esquecer de instalar essa biblioteca
import google.generativeai as genai

# Insira sua chave de API aqui
# Site para gerar a chave: https://aistudio.google.com/app/apikey
genai.configure(api_key="")

for m in genai.list_models():

    if 'generateContent' in m.supported_generation_methods:
        print(m.name)

model = genai.GenerativeModel('gemini-pro')
input = input("Digite o seu problema: ")
response = model.generate_content("Vou explicar a você um problema que estou enfrentando com meu carro, e preciso que "
                                  "você me diga o que provavelmente ele tem de problema, o que será preciso consertar "
                                  "e quanto provavelmente custará. Sempre dê os valores em reais." + input)

print(response.text)