def exibir_menu():
    print("Cadastro de Veículos")
    print("")
    print("1. Adicionar Veículo")
    print("2. Listar Veículos cadastrados")
    print("Digite 'sair' para encerrar o programa.")


def adicionar_veiculo(veiculos):
    placa = input("Digite a placa do veículo: ")
    marca = input("Digite a marca do veículo: ")
    modelo = input("Digite o modelo do veículo: ")
    ano = input("Digite o ano do veículo: ")

    veiculo = [placa, marca, modelo, ano]
    veiculos.append(veiculo)
    print("Veículo adicionado com sucesso!")


def listar_veiculos(veiculos):
    if not veiculos:
        print("Nenhum veículo cadastrado.")
    else:
        print("\n--- Lista de Veículos ---")
        for veiculo in veiculos:
            print(f"Placa: {veiculo[0]}, Marca: {veiculo[1]}, Modelo: {veiculo[2]}, Ano: {veiculo[3]}")


def main():
    veiculos = []

    while True:
        exibir_menu()
        opcao = input("Escolha uma opção: ")

        if opcao.lower() == "sair":  # Transformando a resposta do usuario em minuscula
            print("Encerrando o programa...")
            break

        if opcao == '1':
            adicionar_veiculo(veiculos)
        elif opcao == '2':
            listar_veiculos(veiculos)
        elif opcao == '3':
            print("Saindo...")
            break
        else:
            print("Opção inválida. Tente novamente.")

main()
