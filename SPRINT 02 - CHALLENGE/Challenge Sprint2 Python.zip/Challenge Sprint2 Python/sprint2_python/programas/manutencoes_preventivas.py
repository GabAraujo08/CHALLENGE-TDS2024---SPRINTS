# Função para exibir opções de mecânicas e permitir ao usuário escolher
def escolher_mecanica(servico):
    print(f"Mecânicas próximas que oferecem {servico}:")
    # Exemplos de mecânicas:
    print("1- Mecânica Auto")
    print("Endereço: Rua A, 123")
    print("Valor cobrado: R$ xxx")
    print("")
    print("2- Mecânica MotoresTop")
    print("Endereço: Rua B, 456")
    print("Valor cobrado: R$ xxx")
    # E vai assim por diante oferecendo opções de mecânicas e o valor da manutenção
    return int(input("Digite a opção da mecânica que melhor te atende: "))


# Função para agendar serviço em uma mecânica
def agendar_servico():
    disponibilidade = []

    for dia in range(30):  # 30 dias do mês
        horarios = []
        for hora in range(8, 19):  # Horários das 8h às 18h
            horarios.append(hora)
        disponibilidade.append(horarios)

        # Exibir dias e horários disponíveis para agendamento
    print("Dias e horários disponíveis para agendamento:")
    for dia in range(30):
        print("Dia", dia + 1, ":", disponibilidade[dia])

        # O usuário escolhe um dia e um horário
    dia_escolhido = int(input("Escolha um dia para o agendamento (1 a 30): ")) - 1
    horario_escolhido = int(input("Escolha um horário para o agendamento (8 a 18): "))

    # Verificar se o dia e horário escolhidos são válidos
    if 0 <= dia_escolhido < 30:
        if horario_escolhido in disponibilidade[dia_escolhido]:

            # Remover o horário escolhido do dia escolhido
            disponibilidade[dia_escolhido].remove(horario_escolhido)
            print("Agendamento realizado para o dia", dia_escolhido + 1, "às", horario_escolhido, "h.")
        else:
            print("Horário inválido ou já ocupado. Tente novamente.")
    else:
        print("Dia inválido. Tente novamente.")


# Função para lidar com o menu de serviços
def menu_servicos():
    while True:
        print("1- Motor")
        print("2- Sistema elétrico")
        print("3- Sistema de Arrefecimento")
        print("4- Sistema de freios")
        print("5- Suspensao e direção")
        print("6- Pneus e rodas")
        print("Digite 'sair' para encerrar o programa.")
        print("")
        opc = input("Digite o número da manutenção que deseja: ")

        # If true: encerrar o programa
        if opc.lower() == "sair":  # Transformando a resposta do usuario em minuscula
            print("Encerrando o programa...")
            break

        opc = int(opc)

        if opc in range(1, 7):
            if opc == 1:
                print("1- Troca de óleo e filtro de óleo")
                print("2- Substituição de velas de ignição")
                print("3- Substituição de correias e correntes")
            elif opc == 2:
                print("1- Substituição da bateria")
                print("2- Inspeção e reparo de fiação e conectores")
                print("3- Substituição de fusíveis e relés")
            elif opc == 3:
                print("1- Troca do líquido de arrefecimento")
                print("2- Verificação e substituição de mangueiras do radiador")
                print("3- Substituição do termostato")
            elif opc == 4:
                print("1- Substituição de pastilhas de freio")
                print("2- Substituição dos discos de freio")
                print("3- Troca de fluido de freio")
            elif opc == 5:
                print("Subserviços disponíveis:")
                print("1- Substituição de amortecedores")
                print("2- Verificação e substituição de buchas e articulações")
                print("3- Verificação e substituição da barra estabilizadora")
            elif opc == 6:
                print("Subserviços disponíveis:")
                print("1- Verificação e substituição das pastilhas de freio")
                print("2- Rodízio dos pneus")
                print("3- Alinhamento e balanceamento das rodas")

            sub_opc = int(input("Digite o número da opção que deseja: "))
            if sub_opc in range(1, 4):
                mecanica = escolher_mecanica("serviço")
                agendar_servico()
            else:
                print("Opção inválida. Tente novamente.")
        else:
            print("Opção inválida. Tente novamente.")


# Executar o menu de serviços
menu_servicos()
