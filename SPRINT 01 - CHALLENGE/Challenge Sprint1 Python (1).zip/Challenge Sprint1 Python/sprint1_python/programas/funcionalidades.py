# Menu opções
while True: # Rodar o programa até a condição if ser false
    print("Menu opções")
    print("")
    print("1- Cadastro de veículo")
    print("2- Manutenções frequentes")
    print("3- Suporte ao cliente")
    print("Digite 'sair' para encerrar o programa.")
    print("")
    opcao = input("Digite a opção que deseja? ")

    # If true: encerrar o programa
    if opcao.lower() == "sair": # Transformando a resposta do usuario em minuscula
        print("Encerrando o programa...")
        break

    match opcao:
        case "1":  # Cadastro de veículo
                print("Cadastro de veículo")
                print("")
                modelo = input("Insira o modelo do seu automóvel: ")
                ano = int(input("Insira o ano do seu automóvel: "))
                placa = input("Insira a placa do seu automóvel: ")
                print("Veículo cadastrado com sucesso.")
                print("")

        case "2":  # Manutenções frequentes
                print("Manutenções frequentes")
                print("")
                print("1º - Mostrar opções de manutenções frequentes"
                      "\n2º - Mostrar serviços daquela manutenção"
                      "\n3º - Mostrar mecânicas próximas, o endereço e o valor que elas cobram para o serviço"
                      "\n4º - Gerar um calendário com os dias e horários disponíveis para o agendamento")
                print("")

        case "3":  # Suporte ao cliente
                print("Suporte ao cliente")
                print("")
                print("O cliente terá uma aba para suporte, onde poderá tirar dúvidas com um chat ou acessar a página de dúvidas frequentes.")
                print("")

        case _:  # Opção inválida, usuario digitou qualquer coisa que não esteja nas especificações
                print("Entrada inválida, por favor insira um número valido ou 'sair' para encerrar.")
