def main():
    usuarios = []
    resp = 1
    while resp != 0:
        print("1-Inserir usuário")
        print("2-Alterar usuário")
        print("3-Excluir usuário")
        print("4-Exibir usuários")
        opc = int(input("Digite a opção desejada (1-4): "))
        match opc:
            case 1:
                inserir_usuario(usuarios)
            case 2:
                email = input("Digite o email do usuário a ser alterado: ")
                indice = buscar_usuario(usuarios, email)
                if (indice != -1):
                    alterar_usuario(usuarios, indice)
                else:
                    print("Usuário não existe!")
            case 3:
                email = input("Digite o email do usuário a ser excluído: ")
                indice = buscar_usuario(usuarios, email)
                if (indice != -1):
                    excluir_usuario(usuarios, indice)
                else:
                    print("Usuário não existe!")
            case 4:
                exibir_usuarios(usuarios)
            case _:
                print("Opção inválida")
        resp = int(input("Deseja continuar (1-SIM/0-NÃO)? "))


def buscar_usuario(usuarios, email):
    for i in range(len(usuarios)):
        if usuarios[i]['Email'] == email:
            return i
    return -1

def inserir_usuario(usuarios):
    try:
        email = input("Email: ")
        indice = buscar_usuario(usuarios, email)
        while (indice != -1):
            email = input("Email já existente. Digite outro email para inserir: ")
            indice = buscar_usuario(usuarios, email)
        nome = input("Nome: ")
        data_nascimento = input("Data de Nascimento (DD/MM/AAAA): ")
        telefone = input("Número de Telefone: ")
        cpf = input("CPF: ")
    except ValueError:
        print("Erro ao inserir dados!")
    else:
        usuario = {
            'Email': email,
            'Nome': nome,
            'Data de Nascimento': data_nascimento,
            'Telefone': telefone,
            'CPF': cpf
        }
        usuarios.append(usuario)
        print("Dados inseridos com sucesso")
    finally:
        print("Operação finalizada")

def alterar_usuario(usuarios, indice):
    try:
        print(f"Email: {usuarios[indice]['Email']}")
        email = input("Digite o novo email: ")
        print(f"Nome: {usuarios[indice]['Nome']}")
        nome = input("Digite o novo nome: ")
        print(f"Data de Nascimento: {usuarios[indice]['Data de Nascimento']}")
        data_nascimento = input("Digite a nova data de nascimento (DD/MM/AAAA): ")
        print(f"Número de Telefone: {usuarios[indice]['Telefone']}")
        telefone = input("Digite o novo número de telefone: ")
        print(f"CPF: {usuarios[indice]['CPF']}")
        cpf = input("Digite o novo CPF: ")
    except ValueError:
        print("Erro ao alterar dados!")
    else:
        usuarios[indice]['Email'] = email
        usuarios[indice]['Nome'] = nome
        usuarios[indice]['Data de Nascimento'] = data_nascimento
        usuarios[indice]['Telefone'] = telefone
        usuarios[indice]['CPF'] = cpf
        print("Dados alterados com sucesso!")
    finally:
        print("Operação finalizada")

def excluir_usuario(usuarios, indice):
    usuarios.pop(indice)
    print("Usuário excluído com sucesso!")

def exibir_usuarios(usuarios):
    for i in range(len(usuarios)):
        for chave, valor in usuarios[i].items():
            print(f"{chave}: {valor}")
        print("-------------------------------------")

if __name__ == "__main__":
    main()