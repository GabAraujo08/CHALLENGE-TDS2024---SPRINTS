def main():
    servicos = []
    resp = 1
    while resp != 0:
        print("1-Inserir solicitação de serviço")
        print("2-Alterar solicitação de serviço")
        print("3-Excluir solicitação de serviço")
        print("4-Exibir solicitações de serviço")
        opc = int(input("Digite a opção desejada (1-4): "))
        match opc:
            case 1:
                inserir_servico(servicos)
            case 2:
                id_servico = input("Digite o ID da solicitação de serviço a ser alterada: ")
                indice = buscar_servico(servicos, id_servico)
                if (indice != -1):
                    alterar_servico(servicos, indice)
                else:
                    print("Serviço não existe!")
            case 3:
                id_servico = input("Digite o ID da solicitação de serviço a ser excluída: ")
                indice = buscar_servico(servicos, id_servico)
                if (indice != -1):
                    excluir_servico(servicos, indice)
                else:
                    print("Serviço não existe!")
            case 4:
                exibir_servicos(servicos)
            case _:
                print("Opção inválida")
        resp = int(input("Deseja continuar (1-SIM/0-NÃO)? "))


def buscar_servico(servicos, id_servico):
    for i in range(len(servicos)):
        if servicos[i]['ID'] == id_servico:
            return i
    return -1

def inserir_servico(servicos):
    try:
        id_servico = input("ID do Serviço: ")
        indice = buscar_servico(servicos, id_servico)
        while (indice != -1):
            id_servico = input("ID já existente. Digite outro ID para inserir: ")
            indice = buscar_servico(servicos, id_servico)
        tipo = input("Tipo de Serviço: ")
        descricao = input("Descrição: ")
        data = input("Data: ")
    except ValueError:
        print("Erro ao inserir dados!")
    else:
        servico = {'ID': id_servico, 'Tipo': tipo, 'Descricao': descricao, 'Data': data}
        servicos.append(servico)
        print("Solicitação de serviço inserida com sucesso")
    finally:
        print("Operação finalizada")

def alterar_servico(servicos, indice):
    try:
        print(f"ID: {servicos[indice]['ID']}")
        id_servico = input("Digite o novo ID: ")
        print(f"Tipo: {servicos[indice]['Tipo']}")
        tipo = input("Digite o novo tipo de serviço: ")
        print(f"Descrição: {servicos[indice]['Descricao']}")
        descricao = input("Digite a nova descrição: ")
        print(f"Data: {servicos[indice]['Data']}")
        data = input("Digite a nova data: ")
    except ValueError:
        print("Erro ao alterar dados!")
    else:
        servicos[indice]['ID'] = id_servico
        servicos[indice]['Tipo'] = tipo
        servicos[indice]['Descricao'] = descricao
        servicos[indice]['Data'] = data
        print("Solicitação de serviço alterada com sucesso!")
    finally:
        print("Operação finalizada")

def excluir_servico(servicos, indice):
    servicos.pop(indice)
    print("Solicitação de serviço excluída com sucesso!")

def exibir_servicos(servicos):
    for i in range(len(servicos)):
        for chave, valor in servicos[i].items():
            print(f"{chave}: {valor}")
        print("-------------------------------------")

if __name__ == "__main__":
    main()
