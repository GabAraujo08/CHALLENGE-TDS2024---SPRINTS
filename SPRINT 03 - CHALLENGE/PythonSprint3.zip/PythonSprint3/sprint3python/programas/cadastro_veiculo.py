def main():
    veiculos = []
    resp = 1
    while resp != 0:
        print("1-Inserir veiculo")
        print("2-Alterar veiculo")
        print("3-Excluir veiculo")
        print("4-Exibir veiculo")
        opc = int(input("Digite a opção desejada (1-4): "))
        match opc:
            case 1:
                inserir_veiculo(veiculos)
            case 2:
                placa = input("Digite a placa do veiculo a ser alterado: ")
                indice = buscar_veiculo(veiculos, placa)
                if (indice != -1):
                    alterar_veiculo(veiculos, indice)
                else:
                    print("Veiculo não existe!")
            case 3:
                placa = input("Digite a placa do veiculo a ser excluído: ")
                indice = buscar_veiculo(veiculos, placa)
                if (indice != -1):
                    excluir_veiculo(veiculos, indice)
                else:
                    print("Veiculo não existe!")
            case 4:
                exibir_veiculos(veiculos)
            case _:
                print("Opção inválida")
        resp = int(input("Deseja continuar (1-SIM/0-NÃO)? "))


def buscar_veiculo(veiculos, placa):
    for i in range(len(veiculos)):
        if veiculos[i]['Placa'] == placa:
            return i
    return -1

def inserir_veiculo(veiculos):
    try:
        placa = input("Placa: ")
        indice = buscar_veiculo(veiculos, placa)
        while (indice != -1):
            placa = input("Placa já existente. Digite outra placa para inserir: ")
            indice = buscar_veiculo(veiculos, placa)
        marca = input("Marca: ")
        modelo = input("Modelo: ")
        ano = int(input("Ano: "))
    except ValueError:
        print("Digite valores numéricos!")
    else:
        veiculo = {'Placa': placa, 'Marca': marca, 'Modelo': modelo, 'Ano': ano}
        veiculos.append(veiculo)
        print("Dados inseridos com sucesso")
    finally:
        print("Operação finalizada")

def alterar_veiculo(veiculos, indice):
    try:
        print(f"Placa: {veiculos[indice]['Placa']}")
        placa = input("Digite a nova placa: ")
        print(f"Marca: {veiculos[indice]['Marca']}")
        marca = input("Digite a nova marca: ")
        print(f"Modelo: {veiculos[indice]['Modelo']}")
        modelo = input("Digite o novo modelo: ")
        print(f"Ano: {veiculos[indice]['Ano']}")
        ano = int(input("Digite o novo ano: "))
    except ValueError:
        print("Digite valores numéricos!")
    else:
        veiculos[indice]['Placa'] = placa
        veiculos[indice]['Marca'] = marca
        veiculos[indice]['Modelo'] = modelo
        veiculos[indice]['Ano'] = ano
        print("Dados alterados com sucesso!")
    finally:
        print("Operação finalizada")

def excluir_veiculo(veiculos, indice):
    veiculos.pop(indice)
    print("Veiculo excluído com sucesso!")

def exibir_veiculos(veiculos):
    for i in range(len(veiculos)):
        for chave, valor in veiculos[i].items():
            print(f"{chave}: {valor}")
        print("-------------------------------------")

if __name__ == "__main__":
    main()
