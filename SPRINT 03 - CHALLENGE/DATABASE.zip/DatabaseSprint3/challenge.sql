CREATE TABLE T_USUARIO(
    cpf CHAR(12) PRIMARY KEY,                           
    nm_usuario varchar2(110) NOT NULL,                  
    email varchar2(110) UNIQUE NOT NULL,                         
    dt_nasc DATE NOT NULL,
    senha_login varchar2(50) NOT NULL,                 
    telefone_usuario varchar2(20) NOT NULL,
    endereco_usuario varchar2(100) NOT NULL
);

CREATE TABLE T_MECANICA(
    cnpj_mecanica CHAR(14) PRIMARY KEY,               
    nm_mecanica varchar2(110) NOT NULL,                 
    endereco_mecanica varchar2(200) NOT NULL,           
    telefone_mecanica varchar2(20) UNIQUE NOT NULL,             
    lista_servicos varchar2(500) NOT NULL
);

CREATE TABLE T_PECAS(
    id_peca INT PRIMARY KEY,                           
    nm_peca varchar2(100) NOT NULL,                  
    marca_peca varchar2(20) NOT NULL,                   
    valor_peca NUMBER(5,2) NOT NULL CHECK (valor_peca >= 0),          
    descricao_peca varchar2(150) NOT NULL
);

CREATE TABLE T_SERVICO(
    id_servico INT PRIMARY KEY,                         
    nm_servico varchar2(100) UNIQUE NOT NULL,                    
    descricao varchar2(500)NOT NULL,
    categoria varchar2(50)NOT NULL,
    valor_servico NUMBER(5,2) NOT NULL CHECK (valor_servico >= 0)    
);

CREATE TABLE T_VEICULO(
    placa varchar2(9) PRIMARY KEY,                      
    fk_cpf CHAR(12) NOT NULL,
    FOREIGN KEY (fk_cpf) REFERENCES T_USUARIO(cpf),    
    marca_veiculo varchar2(20) NOT NULL,                
    modelo_veiculo varchar2(50) NOT NULL,               
    ano_fabricacao CHAR(4) NOT NULL,
    cor varchar2(30)NOT NULL,
    km_veiculo INT NOT NULL CHECK (km_veiculo >= 0),             
    tipo_veiculo varchar2(20) NOT NULL
);

CREATE TABLE T_DIAGNOSTICO(
    id_diagnostico INT PRIMARY KEY,                    
    descricao_problema varchar2(500) NOT NULL,           
    fk_placa varchar2(9) NOT NULL,
    FOREIGN KEY (fk_placa) REFERENCES T_VEICULO(placa)
);

CREATE TABLE T_AGENDAMENTO(
    id_agendamento INT PRIMARY KEY,                                   
    fk_cpf CHAR(12) NOT NULL,
    FOREIGN KEY (fk_cpf) REFERENCES T_USUARIO(cpf),  
    fk_cnpj_mecanica CHAR(14) NOT NULL,
    FOREIGN KEY (fk_cnpj_mecanica) REFERENCES T_MECANICA(cnpj_mecanica),
    dt_hora DATE NOT NULL,                         
    servico varchar2(100) NOT NULL,                  
    st_agendamento CHAR(1) NOT NULL CHECK (st_agendamento = 'T' OR st_agendamento = 'F')
);


CREATE TABLE T_ORCAMENTO(
    id_orcamento INT PRIMARY KEY,                                      
    nm_servico varchar2(100) NOT NULL,
    fk_id_diagnostico int NOT NULL,      
    FOREIGN KEY (fk_id_diagnostico) REFERENCES T_DIAGNOSTICO(id_diagnostico),
    fk_cnpj_mecanica CHAR(14) NOT NULL,
    FOREIGN KEY (fk_cnpj_mecanica) REFERENCES T_MECANICA(cnpj_mecanica),
    lista_pecas varchar2(1000) NOT NULL,
    valor_orcamento NUMBER NOT NULL CHECK (valor_orcamento >= 0) 
);


CREATE TABLE T_FEEDBACK(
    id_feedback INT PRIMARY KEY,                        
    nota NUMBER NOT NULL,
    comentarios varchar2(500) NOT NULL,
    fk_cpf CHAR(12) NOT NULL,
    FOREIGN KEY (fk_cpf) REFERENCES T_USUARIO(cpf),  
    fk_cnpj_mecanica CHAR(14) NOT NULL,
    FOREIGN KEY (fk_cnpj_mecanica) REFERENCES T_MECANICA(cnpj_mecanica) 
);


