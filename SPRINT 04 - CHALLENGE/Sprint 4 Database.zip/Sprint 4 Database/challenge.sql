/*
558802 - GABRIEL ARAUJO DA SILVA BRITO

558962 - GABRIELLY CAMPOS MACEDO

554522 - Thiago Henry Dias
*/


CREATE TABLE T_USUARIO (
    id_usuario INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    cpf CHAR(11) UNIQUE NOT NULL,                           
    nm_usuario VARCHAR2(110) NOT NULL,                  
    email VARCHAR2(110) UNIQUE NOT NULL,                         
    dt_nasc DATE NOT NULL,
    senha_login VARCHAR2(50) NOT NULL,                 
    telefone_usuario VARCHAR2(20) NOT NULL,
    endereco_usuario VARCHAR2(100) NOT NULL
);


CREATE TABLE T_MECANICA (
    id_mecanica INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    cnpj_mecanica CHAR(14) UNIQUE NOT NULL,               
    nm_mecanica VARCHAR2(110) NOT NULL,                 
    endereco_mecanica VARCHAR2(200) NOT NULL,           
    telefone_mecanica VARCHAR2(20) UNIQUE NOT NULL
);

CREATE TABLE T_PECAS (
    id_peca INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,                           
    nm_peca VARCHAR2(100) NOT NULL,                  
    marca_peca VARCHAR2(20) NOT NULL,                   
    valor_peca NUMBER(5, 2) NOT NULL CHECK (valor_peca >= 0),          
    descricao_peca VARCHAR2(150) NOT NULL
);

CREATE TABLE T_SERVICO (
    id_servico INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,                         
    nm_servico VARCHAR2(100) UNIQUE NOT NULL,                    
    descricao VARCHAR2(80) NOT NULL,  
    categoria VARCHAR2(50) NOT NULL,
    valor_servico NUMBER(5, 2) NOT NULL CHECK (valor_servico >= 0)    
);

CREATE TABLE T_VEICULO (
    placa VARCHAR2(7) PRIMARY KEY,                     
    fk_id_usuario INT NOT NULL,
    FOREIGN KEY (fk_id_usuario) REFERENCES T_USUARIO(id_usuario),    
    marca_veiculo VARCHAR2(20) NOT NULL,                
    modelo_veiculo VARCHAR2(50) NOT NULL,               
    ano_fabricacao CHAR(4) NOT NULL,
    cor VARCHAR2(30) NOT NULL,
    km_veiculo INT NOT NULL CHECK (km_veiculo >= 0),             
    tipo_veiculo VARCHAR2(20) NOT NULL
);

CREATE TABLE T_DIAGNOSTICO (
    id_diagnostico INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,                    
    descricao_problema VARCHAR2(200) NOT NULL, 
    diagnostico_problema VARCHAR2(200) NOT NULL,
    fk_placa VARCHAR2(7) NOT NULL,
    FOREIGN KEY (fk_placa) REFERENCES T_VEICULO(placa)
);



CREATE TABLE T_MECANICA_T_SERVICO (
    fk_id_mecanica INT NOT NULL,
    FOREIGN KEY (fk_id_mecanica) REFERENCES T_MECANICA(id_mecanica),
    fk_id_servico INT NOT NULL,
    FOREIGN KEY (fk_id_servico) REFERENCES T_SERVICO(id_servico),
    id_t_mecanica_t_servico INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY
);

CREATE TABLE T_AGENDAMENTO (
    id_agendamento INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,                                   
    fk_id_usuario INT NOT NULL,                                         
    FOREIGN KEY (fk_id_usuario) REFERENCES T_USUARIO(id_usuario),  
    fk_id_mecanica INT NOT NULL,
    FOREIGN KEY (fk_id_mecanica) REFERENCES T_MECANICA(id_mecanica),
    dt_hora TIMESTAMP NOT NULL,                          
    fk_id_servico INT NOT NULL,                                     
    FOREIGN KEY (fk_id_servico) REFERENCES T_SERVICO(id_servico),
    st_agendamento CHAR(1) NOT NULL CHECK (st_agendamento = 'T' OR st_agendamento = 'F')
);

CREATE TABLE T_ORCAMENTO (
    id_orcamento INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,                                      
    fk_id_servico INT NOT NULL,                                        
    FOREIGN KEY (fk_id_servico) REFERENCES T_SERVICO(id_servico),
    fk_id_diagnostico INT NOT NULL,      
    FOREIGN KEY (fk_id_diagnostico) REFERENCES T_DIAGNOSTICO(id_diagnostico),
    fk_id_mecanica INT NOT NULL,
    FOREIGN KEY (fk_id_mecanica) REFERENCES T_MECANICA(id_mecanica),
    lista_pecas VARCHAR2(250) NOT NULL, 
    valor_orcamento NUMBER(5, 2) NOT NULL CHECK (valor_orcamento >= 0) 
);

CREATE TABLE T_FEEDBACK (
    id_feedback INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,                        
    nota NUMBER(2, 1) NOT NULL,  
    comentarios VARCHAR2(80) NOT NULL,  
    fk_id_usuario INT NOT NULL,
    FOREIGN KEY (fk_id_usuario) REFERENCES T_USUARIO(id_usuario),  
    fk_id_mecanica INT NOT NULL,
    FOREIGN KEY (fk_id_mecanica) REFERENCES T_MECANICA(id_mecanica) 
);



INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('91753129052', 'Ana Silva', 'ana.silva@gmail.com', TO_DATE('1990-05-15', 'YYYY-MM-DD'), 'senha123', '11987654321', 'Rua dos Girassóis, 123, São Paulo, SP');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('79037757073', 'Bruno Costa', 'bruno.costa@gmail.com', TO_DATE('1985-08-22', 'YYYY-MM-DD'), 'bruno2023', '21987654321', 'Avenida Atlântica, 456, Rio de Janeiro, RJ');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('93554703044', 'Carla Oliveira', 'carla.oliveira@gmail.com', TO_DATE('1992-02-10', 'YYYY-MM-DD'), 'carla@2023', '31987654321', 'Rua da Liberdade, 789, Belo Horizonte, MG');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('04505560007', 'Daniel Souza', 'daniel.souza@gmail.com', TO_DATE('1988-12-30', 'YYYY-MM-DD'), 'dani@1234', '41987654321', 'Praça Rui Barbosa, 101, Curitiba, PR');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('62974558054', 'Eduarda Lima', 'eduarda.lima@gmail.com', TO_DATE('1995-03-25', 'YYYY-MM-DD'), 'edu@pass123', '51987654321', 'Avenida dos Estados, 202, Porto Alegre, RS');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('47951098000', 'Felipe Almeida', 'felipe.almeida@gmail.com', TO_DATE('1991-06-14', 'YYYY-MM-DD'), 'felipe@2023', '61987654321', 'Rua das Flores, 303, Brasília, DF');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('07196452046', 'Giselle Rocha', 'giselle.rocha@gmail.com', TO_DATE('1989-09-05', 'YYYY-MM-DD'), 'gigi@2023', '71987654321', 'Rua do Comércio, 404, Salvador, BA');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('29997967062', 'Henrique Dias', 'henrique.dias@gmail.com', TO_DATE('1993-11-20', 'YYYY-MM-DD'), 'henrique2023', '81987654321', 'Avenida da Praia, 505, Recife, PE');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('97419484090', 'Isabella Martins', 'isabella.martins@gmail.com', TO_DATE('1994-07-30', 'YYYY-MM-DD'), 'isabella@2023', '91987654321', 'Rua da Amizade, 606, Fortaleza, CE');

INSERT INTO T_USUARIO (cpf, nm_usuario, email, dt_nasc, senha_login, telefone_usuario, endereco_usuario) VALUES 
    ('20286192012', 'João Pedro', 'joao.pedro@gmail.com', TO_DATE('1987-04-17', 'YYYY-MM-DD'), 'joaopedro123', '11987654322', 'Praça dos Três Poderes, 707, Manaus, AM');








INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('12345678000195', 'Mecânica do João', 'Avenida dos Trabalhadores, 123, São Paulo, SP', '11987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('23456789000100', 'Oficina do Carlos', 'Rua das Palmeiras, 456, Rio de Janeiro, RJ', '21987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('34567890000185', 'Auto Center ABC', 'Rua da Liberdade, 789, Belo Horizonte, MG', '31987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('45678901000196', 'Mecânica do Zé', 'Praça dos Três Poderes, 101, Curitiba, PR', '41987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('56789012000100', 'Oficina do Paulo', 'Avenida São João, 202, Porto Alegre, RS', '51987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('67890123000145', 'Auto Peças e Serviços', 'Rua das Flores, 303, Brasília, DF', '61987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('78901234000100', 'Mecânica da Néia', 'Rua do Comércio, 404, Salvador, BA', '71987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('89012345000187', 'Oficina do Henrique', 'Avenida da Praia, 505, Recife, PE', '81987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('90123456000102', 'Mecânica 4 Rodas', 'Rua da Amizade, 606, Fortaleza, CE', '91987654321');

INSERT INTO T_MECANICA (cnpj_mecanica, nm_mecanica, endereco_mecanica, telefone_mecanica) VALUES 
('01234567000190', 'Mecânica do Ricardo', 'Praça do Povo, 707, Manaus, AM', '11987654322');







INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Pastilha de Freio', 'Bosch', 150.00, 'Pastilha de freio dianteira para carros de passeio.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Amortecedor', 'Monroe', 400.50, 'Amortecedor traseiro, compatível com diversos modelos.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Filtro de Óleo', 'Fram', 30.00, 'Filtro de óleo para motores a gasolina e diesel.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Bateria', 'Exide', 500.00, 'Bateria automotiva de 60Ah, ideal para carros de passeio.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Velas de Ignição', 'NGK', 75.00, 'Conjunto com 4 velas de ignição, alta performance.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Correia Dentada', 'Dayco', 120.00, 'Correia dentada para motores de até 2.0L.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Lâmpada Halógena', 'Philips', 45.00, 'Lâmpada halógena H4, 60/55W.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Sensor de Estacionamento', 'Valeo', 200.00, 'Sensor de estacionamento para instalação em carros.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Disco de Freio', 'Ate', 220.00, 'Disco de freio ventilado para a linha de carros nacionais.');

INSERT INTO T_PECAS (nm_peca, marca_peca, valor_peca, descricao_peca) VALUES 
('Radiador', 'Marelli', 650.00, 'Radiador de água para motores, compatível com diversos modelos.');







INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Troca de Óleo', 'Serviço de troca de óleo do motor.', 'Manutenção', 120.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Alinhamento e Balanceamento', 'Alinhamento e balanceamento de rodas.', 'Suspensão', 150.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Troca de Pastilhas de Freio', 'Substituição das pastilhas de freio dianteiras.', 'Freios', 180.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Revisão Completa', 'Revisão completa do veículo com troca de filtros e fluidos.', 'Manutenção', 350.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Instalação de Bateria', 'Instalação e teste de bateria automotiva.', 'Elétrica', 80.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Troca de Amortecedores', 'Substituição dos amortecedores traseiros.', 'Suspensão', 600.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Limpeza de Bicos Injetores', 'Limpeza dos bicos injetores para melhor desempenho.', 'Motor', 200.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Troca de Correia Dentada', 'Substituição da correia dentada do motor.', 'Manutenção', 250.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Serviço de Lavagem', 'Lavagem completa do veículo, interna e externa.', 'Estética', 100.00);

INSERT INTO T_SERVICO (nm_servico, descricao, categoria, valor_servico) VALUES 
('Instalação de Sensor de Estacionamento', 'Instalação de sensores de estacionamento.', 'Acessórios', 220.00);











INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('ABC1D23', 1, 'Toyota', 'Corolla', '2020', 'Prata', 15000, 'Sedan');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('XYZ2E34', 2, 'Honda', 'Civic', '2019', 'Preto', 25000, 'Sedan');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('JKL3F45', 3, 'Ford', 'Focus', '2021', 'Branco', 5000, 'Hatchback');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('LMN4G56', 4, 'Chevrolet', 'Onix', '2022', 'Vermelho', 2000, 'Hatchback');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('QRS5H67', 5, 'Hyundai', 'HB20', '2018', 'Azul', 30000, 'Hatchback');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('TUV6I78', 6, 'Volkswagen', 'Gol', '2020', 'Cinza', 15000, 'Hatchback');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('WXY7J89', 7, 'Nissan', 'Kicks', '2021', 'Verde', 8000, 'SUV');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('PQR8K90', 8, 'Fiat', 'Toro', '2022', 'Branco', 1200, 'Pickup');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('STU9L01', 9, 'Kia', 'Sportage', '2023', 'Preto', 500, 'SUV');

INSERT INTO T_VEICULO (placa, fk_id_usuario, marca_veiculo, modelo_veiculo, ano_fabricacao, cor, km_veiculo, tipo_veiculo) VALUES 
('VWX0M12', 10, 'Renault', 'Duster', '2021', 'Prata', 6000, 'SUV');






INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Motor faz barulho estranho ao acelerar', 'Possível desgaste nos rolamentos ou problema no sistema de escape', 'ABC1D23');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Bateria descarregando rapidamente', 'Verificar o alternador e possíveis fugas de corrente elétrica', 'XYZ2E34');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Falha na ignição em dias frios', 'Pode ser necessário substituir as velas ou verificar o sistema de aquecimento do motor', 'JKL3F45');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Pneus desgastados', 'Recomendado substituir os pneus e realizar alinhamento e balanceamento', 'LMN4G56');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Alinhamento do volante fora do padrão', 'Realizar alinhamento e verificar sistema de direção', 'QRS5H67');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Problema nos freios ABS', 'Verificar sensores do ABS e realizar diagnóstico do sistema de frenagem', 'TUV6I78');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Luz de verificação do motor acesa', 'Diagnóstico eletrônico necessário para identificar possíveis falhas', 'WXY7J89');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Vibração ao acelerar', 'Possível desgaste nos suportes do motor ou nos eixos de transmissão', 'PQR8K90');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Ruído no escapamento', 'Verificar o sistema de escape para possíveis vazamentos ou peças soltas', 'STU9L01');

INSERT INTO T_DIAGNOSTICO (descricao_problema, diagnostico_problema, fk_placa) VALUES 
('Desgaste excessivo das pastilhas de freio', 'Substituir as pastilhas de freio e inspecionar discos de freio', 'VWX0M12');




    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (1, 2);

INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (1, 3);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (2, 1);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (2, 4);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (3, 2);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (3, 5);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (4, 1);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (4, 3);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (5, 2);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (5, 6);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (1, 1);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (2, 2);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (3, 3);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (4, 4);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (5, 5);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (1, 6);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (2, 5);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (3, 4);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (4, 2);
    
INSERT INTO T_MECANICA_T_SERVICO (fk_id_mecanica, fk_id_servico) VALUES 
    (5, 1);




INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(1, 1, TO_TIMESTAMP('2024-10-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1, 'T');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(2, 2, TO_TIMESTAMP('2024-10-02 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), 2, 'T');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(3, 3, TO_TIMESTAMP('2024-10-03 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), 3, 'F');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(4, 4, TO_TIMESTAMP('2024-10-04 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), 4, 'T');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(5, 5, TO_TIMESTAMP('2024-10-05 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), 5, 'F');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(6, 6, TO_TIMESTAMP('2024-10-06 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), 6, 'T');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(7, 7, TO_TIMESTAMP('2024-10-07 15:30:00', 'YYYY-MM-DD HH24:MI:SS'), 7, 'T');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(8, 8, TO_TIMESTAMP('2024-10-08 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 8, 'F');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(9, 9, TO_TIMESTAMP('2024-10-09 13:30:00', 'YYYY-MM-DD HH24:MI:SS'), 9, 'T');

INSERT INTO T_AGENDAMENTO (fk_id_usuario, fk_id_mecanica, dt_hora, fk_id_servico, st_agendamento) VALUES 
(10, 10, TO_TIMESTAMP('2024-10-10 09:45:00', 'YYYY-MM-DD HH24:MI:SS'), 10, 'T');








INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(1, 1, 1, 'Óleo de motor, filtro de óleo', 250.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(2, 2, 2, 'Kit alinhamento, balanceamento', 300.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(3, 3, 3, 'Pastilhas de freio, disco de freio', 400.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(4, 4, 4, 'Filtro de ar, fluido de freio, correia dentada', 550.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(5, 5, 5, 'Bateria automotiva', 200.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(6, 6, 6, 'Amortecedores traseiros, molas', 700.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(7, 7, 7, 'Bicos injetores, limpador de injetor', 250.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(8, 8, 8, 'Correia dentada, rolamentos', 350.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(9, 9, 9, 'Produtos de lavagem, cera automotiva', 150.00);

INSERT INTO T_ORCAMENTO (fk_id_servico, fk_id_diagnostico, fk_id_mecanica, lista_pecas, valor_orcamento) VALUES 
(10, 10, 10, 'Sensor de estacionamento, chicote de fios', 300.00);






INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(9.5, 'Ótimo atendimento e serviço rápido.', 1, 1);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(9.9, 'Serviço excelente, recomendo!', 2, 2);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(7.0, 'O serviço foi bom, mas o tempo de espera foi longo.', 3, 3);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(8.0, 'Funcionários atenciosos, mas o preço poderia ser melhor.', 4, 4);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(9.0, 'Tudo foi feito com cuidado, satisfeita com o resultado.', 5, 5);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(6.0, 'O serviço atendeu, mas faltou comunicação.', 6, 6);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(9.9, 'Perfeito! Fui bem atendido e tudo ficou como novo.', 7, 7);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(3.0, 'Não gostei da experiência, não voltarei.', 8, 8);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(8.5, 'Serviço bom, mas a localização é um pouco complicada.', 9, 9);

INSERT INTO T_FEEDBACK (nota, comentarios, fk_id_usuario, fk_id_mecanica) VALUES 
(9.0, 'Recomendo, farei mais serviços aqui.', 10, 10);



SELECT * FROM T_USUARIO;
SELECT * FROM T_MECANICA;
SELECT * FROM T_PECAS;
SELECT * FROM T_SERVICO;
SELECT * FROM T_VEICULO;
SELECT * FROM T_DIAGNOSTICO;
SELECT * FROM T_MECANICA_T_SERVICO;
SELECT * FROM T_AGENDAMENTO;
SELECT * FROM T_ORCAMENTO;
SELECT * FROM T_FEEDBACK;


-- Relatório utilizando classificação de dados, a escolha da tabela é decisão do grupo
SELECT 
    id_agendamento AS "ID do Agendamento",
    fk_id_usuario AS "ID do Usuário",
    fk_id_mecanica AS "ID da Mecânica",
    fk_id_servico AS "ID do Serviço",
    dt_hora AS "Data e Hora",
    st_agendamento AS "Status do Agendamento"
FROM 
    T_AGENDAMENTO
ORDER BY 
    dt_hora ASC;
    

SELECT 
    id_feedback AS "ID do Feedback",
    fk_id_usuario AS "ID do Usuário",
    fk_id_mecanica AS "ID da Mecânica",
    nota AS "Nota",
    comentarios AS "Comentários"
FROM 
    T_FEEDBACK
ORDER BY 
    nota DESC; 




-- Relatório utilizando alguma função do tipo numérica simples
SELECT 
    AVG(nota) AS "Média das Notas",
    MAX(nota) AS "Nota Máxima",
    MIN(nota) AS "Nota Mínima"
FROM 
    T_FEEDBACK;
    
    
SELECT 
    AVG(valor_servico) AS "Média dos valores dos servicos",
    MAX(valor_servico) AS "Servico com o maior valor",
    MIN(valor_servico) AS "Servico com o menor valor"
FROM 
    T_SERVICO;




-- Relatório utilizando alguma função de grupo
SELECT 
    U.nm_usuario,
    COUNT(V.placa) AS total_veiculos
FROM 
    T_USUARIO U
LEFT JOIN 
    T_VEICULO V ON U.id_usuario = V.fk_id_usuario
GROUP BY 
    U.nm_usuario
ORDER BY 
    total_veiculos DESC;


SELECT 
    M.nm_mecanica,
    COUNT(A.id_agendamento) AS total_agendamentos
FROM 
    T_MECANICA M
LEFT JOIN 
    T_AGENDAMENTO A ON M.id_mecanica = A.fk_id_mecanica
GROUP BY 
    M.nm_mecanica
ORDER BY 
    total_agendamentos DESC;




-- Relatório utilizando sub consulta
SELECT 
    U.nm_usuario,
    V.placa,
    V.ano_fabricacao
FROM 
    T_USUARIO U
JOIN 
    T_VEICULO V ON U.id_usuario = V.fk_id_usuario
WHERE 
    V.ano_fabricacao > '2020';


SELECT 
    M.nm_mecanica,
    AVG(F.nota) AS media_feedback
FROM 
    T_MECANICA M
JOIN 
    T_FEEDBACK F ON M.id_mecanica = F.fk_id_mecanica
GROUP BY 
    M.nm_mecanica
HAVING 
    AVG(F.nota) > 7.0;




-- Relatório utilizando junção de tabelas
SELECT 
    V.placa,
    U.nm_usuario,
    U.telefone_usuario,
    V.marca_veiculo,
    V.modelo_veiculo,
    V.ano_fabricacao
FROM 
    T_VEICULO V
JOIN 
    T_USUARIO U ON V.fk_id_usuario = U.id_usuario
ORDER BY 
    U.nm_usuario;
    
   
SELECT 
    A.id_agendamento,
    U.nm_usuario,
    M.nm_mecanica,
    S.nm_servico,
    A.dt_hora,
    A.st_agendamento
FROM 
    T_AGENDAMENTO A
JOIN 
    T_USUARIO U ON A.fk_id_usuario = U.id_usuario
JOIN 
    T_MECANICA M ON A.fk_id_mecanica = M.id_mecanica
JOIN 
    T_SERVICO S ON A.fk_id_servico = S.id_servico
ORDER BY 
    A.dt_hora;





