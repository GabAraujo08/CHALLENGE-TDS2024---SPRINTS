# Prototipo do diagnostico

# Nao esquecer de instalar essa biblioteca
import google.generativeai as genai

# Insira sua chave de API aqui
# Site para gerar a chave: https://aistudio.google.com/app/apikey
genai.configure(api_key="AIzaSyCwhAApbDj2KEyHxbggbYJzaJuZNKVJ2g4")

for m in genai.list_models():

    if 'generateContent' in m.supported_generation_methods:
        print(m.name)

model = genai.GenerativeModel('gemini-pro')
input = input("Digite o seu problema: ")
response = model.generate_content("Estou enfrentando um problema com meu carro e gostaria de sua ajuda para entender "
                                  "melhor a situação. Por favor, me diga qual pode ser o problema, quais reparos "
                                  "são necessários e uma estimativa de custo, com os valores sempre em reais. Aqui "
                                  "estão os detalhes do problema: " + input)

print(response.text)