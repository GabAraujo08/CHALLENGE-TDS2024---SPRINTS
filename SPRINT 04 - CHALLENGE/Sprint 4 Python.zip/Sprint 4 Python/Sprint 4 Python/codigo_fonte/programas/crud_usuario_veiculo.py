import oracledb as orcl
import pandas as pd
from datetime import datetime
import json


def main():
    conexao, inst_SQL, str_autentic = conectar_BD()

    opc_principal = 0
    while (opc_principal != 3 and conexao == True):
        # menu principal
        print("1-Cadastro de Usuario")
        print("2-Cadastro de Veiculo")
        print("3-Sair")
        opc_principal = int(input("Digite a opção desejada (1 a 3): "))

        if (opc_principal == 1):
            opc_usuario = 0

            while (opc_usuario != 5):
                print("1-Inserção de usuario")
                print("2-Alteração de usuario")
                print("3-Exclusão de usuario")
                print("4-Relatório de todos os usuarios")
                print("5-Voltar para o menu principal")
                print("6-Exportar para um arquivo json todos os usuários")
                opc_usuario = int(input("Digite a opção desejada para os usuarios (1 a 5): "))


                if (opc_usuario == 1):
                    try:
                        nome = input("Digite o nome do usuario: ")
                        cpf = input("Digite o CPF do usuario: ").strip()
                        email = input("Digite o email do usuario: ")
                        dt_nasc = input("Digite a data de nascimento do usuario (dd/mm/yyyy): ")
                        senha = input("Digite a senha do usuario: ")
                        telefone = input("Digite o telefone do usuario: ")
                        endereco = input("Digite o endereço do usuario: ")
                        dt_nasc_formatada = datetime.strptime(dt_nasc, "%d/%m/%Y").strftime("%Y-%m-%d")

                    except ValueError:
                        print("Digite dados numéricos!")
                    else:
                        str_insert = f"""INSERT INTO T_USUARIO (CPF, NM_USUARIO, EMAIL, DT_NASC, SENHA_LOGIN, TELEFONE_USUARIO, ENDERECO_USUARIO) VALUES ('{cpf}','{nome}','{email}', TO_DATE('{dt_nasc_formatada}', 'YYYY-MM-DD'),'{senha}','{telefone}','{endereco}')"""
                        insert_tabela(inst_SQL, str_autentic, str_insert)
                elif (opc_usuario == 2):
                    lista_dados = []
                    id_usuario = int(input("Digite o id do usuario a ser alterado: "))

                    consulta = f"""SELECT * FROM T_USUARIO WHERE ID_USUARIO = {id_usuario}"""
                    inst_SQL.execute(consulta)

                    dados = inst_SQL.fetchall()
                    for dado in dados:
                        lista_dados.append(dado)

                    if (len(lista_dados) == 0):
                        print("ID do usuario não encontrado")
                    else:
                        try:
                            nome = input("Digite o nome do usuario: ")
                            dt_nasc = input("Digite a data de nascimento do usuario (dd/mm/yyyy): ")
                            senha = input("Digite a senha do usuario: ")
                            telefone = input("Digite o telefone do usuario: ")
                            endereco = input("Digite o endereço do usuario: ")
                            cpf = input("Digite o CPF do usuario: ").strip()

                            dt_nasc_formatada = datetime.strptime(dt_nasc, "%d/%m/%Y").strftime("%Y-%m-%d")
                        except ValueError:
                            print("Digite dados numéricos")
                        else:
                            str_update = f"""UPDATE T_USUARIO SET NM_USUARIO = '{nome}', DT_NASC=TO_DATE('{dt_nasc_formatada}', 'YYYY-MM-DD'), SENHA_LOGIN = '{senha}', TELEFONE_USUARIO = '{telefone}', ENDERECO_USUARIO = '{endereco}', CPF = '{cpf}' WHERE ID_USUARIO={id_usuario}"""
                            update_tabela(inst_SQL, str_autentic, str_update)
                elif (opc_usuario == 3):
                    lista_dados = []
                    id_usuario = int(input("Digite o id da usuario a ser excluída: "))

                    consulta = f"""SELECT * FROM T_USUARIO WHERE ID_USUARIO = {id_usuario}"""
                    inst_SQL.execute(consulta)

                    dados = inst_SQL.fetchall()
                    for dado in dados:
                        lista_dados.append(dado)

                    if (len(lista_dados) == 0):
                        print("ID do usuario não encontrado")
                    else:
                        str_delete = f"""DELETE FROM T_USUARIO WHERE ID_USUARIO={id_usuario}"""
                        delete_tabela(inst_SQL, str_autentic, str_delete)
                elif (opc_usuario == 4):

                    lista_dados = []
                    inst_SQL.execute("SELECT * FROM T_USUARIO")
                    dados = inst_SQL.fetchall()

                    for dado in dados:
                        lista_dados.append(dado)

                    df_usuarios = pd.DataFrame.from_records(lista_dados,
                                                            columns=['ID_USUARIO', 'CPF', 'NM_USUARIO', 'EMAIL',
                                                                     'DT_NASC', 'SENHA_LOGIN', 'TELEFONE_USUARIO',
                                                                     'ENDERECO_USUARIO'], index='ID_USUARIO')

                    if (df_usuarios.empty):
                        print("Não existe dados na tabela")
                    else:
                        print(df_usuarios)
                        print("\n")
                elif (opc_usuario == 6):
                    nome_arq = input("Digite o nome do arquivo json com extensão (.json): ")
                    exportar_arqjson_usuario(lista_dados, nome_arq)

        elif (opc_principal == 2):
            opc_veiculo = 0
            while (opc_veiculo != 5):
                print("1-Inserção de veiculo")
                print("2-Alteração de veiculo")
                print("3-Exclusão de veiculo")
                print("4-Relatório de todos os veiculos")
                print("5-Voltar para o menu principal")
                print("6-Exportar para um arquivo json todos os veículos")
                opc_veiculo = int(input("Digite a opção desejada para os veiculos (1 a 5): "))


                if (opc_veiculo == 1):
                    try:
                        placa_veiculo = input("Digite a placa do veiculo: ")
                        marca_veiculo = input("Digite a marca do veiculo: ")
                        modelo_veiculo = input("Digite o modelo do veiculo: ")
                        ano_veiculo = int(input("Digite o ano do veiculo: "))
                        cor_veiculo = input("Digite a cor do veiculo: ")
                        km_veiculo = int(input("Digite a quilometragem do veiculo: "))
                        tipo_veiculo = input("Digite o tipo do veiculo: ")

                        lista_dados = []
                        id_usuario = int(input("Digite o id do usuario a ser vinculado ao veiculo: "))

                        consulta = f"""SELECT * FROM T_USUARIO WHERE ID_USUARIO={id_usuario}"""
                        inst_SQL.execute(consulta)

                        dados = inst_SQL.fetchall()
                        for dado in dados:
                            lista_dados.append(dado)

                        if (len(lista_dados) == 0):
                            print("O ID do usuario que está querendo vincular não existe")

                    except ValueError:
                        print("Digite dados numéricos")
                    else:
                        str_insert = f"""INSERT INTO T_VEICULO (PLACA, MARCA_VEICULO, MODELO_VEICULO, ANO_FABRICACAO, COR, KM_VEICULO, TIPO_VEICULO, FK_ID_USUARIO) VALUES ('{placa_veiculo}','{marca_veiculo}','{modelo_veiculo}',{ano_veiculo},'{cor_veiculo}',{km_veiculo}, '{tipo_veiculo}', {id_usuario})"""
                        insert_tabela(inst_SQL, str_autentic, str_insert)

                elif (opc_veiculo == 2):
                    lista_dados = []

                    pk_veiculo = input("Digite a placa do veiculo a ser alterado: ")

                    consulta = f"""SELECT * FROM T_VEICULO WHERE PLACA='{pk_veiculo}'"""
                    inst_SQL.execute(consulta)

                    dados = inst_SQL.fetchall()
                    for dado in dados:
                        lista_dados.append(dado)

                    if (len(lista_dados) == 0):
                        print("A placa do veiculo a ser alterado não existe")
                    else:
                        try:
                            marca_veiculo = input("Digite a marca do veiculo: ")
                            modelo_veiculo = input("Digite o modelo do veiculo: ")
                            ano_veiculo = int(input("Digite o ano do veiculo: "))
                            cor_veiculo = input("Digite a cor do veiculo: ")
                            km_veiculo = int(input("Digite a quilometragem do veiculo: "))
                            tipo_veiculo = input("Digite o tipo do veiculo: ")

                        except ValueError:
                            print("Digite dados numéricos")
                        else:
                            str_update = f"""UPDATE T_VEICULO SET MARCA_VEICULO='{marca_veiculo}',MODELO_VEICULO='{modelo_veiculo}',ANO_FABRICACAO={ano_veiculo},COR='{cor_veiculo}',KM_VEICULO={km_veiculo},TIPO_VEICULO='{tipo_veiculo}' WHERE PLACA='{pk_veiculo}'"""
                            update_tabela(inst_SQL, str_autentic, str_update)

                elif (opc_veiculo == 3):
                    lista_dados = []

                    pk_veiculo = input("Digite a placa do veiculo a ser excluido: ")

                    consulta = f"""SELECT * FROM T_VEICULO WHERE PLACA='{pk_veiculo}'"""
                    inst_SQL.execute(consulta)

                    dados = inst_SQL.fetchall()
                    for dado in dados:
                        lista_dados.append(dado)

                    if (len(lista_dados) == 0):
                        print("A placa do veiculo a ser excluido não existe")
                    else:
                        str_delete = f"""DELETE FROM T_VEICULO WHERE PLACA='{pk_veiculo}'"""
                        delete_tabela(inst_SQL, str_autentic, str_delete)

                elif (opc_veiculo == 4):

                    lista_dados = []
                    inst_SQL.execute("SELECT * FROM T_VEICULO")
                    dados = inst_SQL.fetchall()

                    for dado in dados:
                        lista_dados.append(dado)

                    df_veiculos = pd.DataFrame.from_records(lista_dados,
                                                            columns=['PLACA', 'FK_ID_USUARIO', 'MARCA_VEICULO', 'MODELO_VEICULO',
                                                                     'ANO_FABRICACAO', 'COR', 'KM_VEICULO',
                                                                     'TIPO_VEICULO'])

                    if (df_veiculos.empty):
                        print("Não existe dados na tabela")
                    else:
                        print(df_veiculos)
                        print("\n")
                elif (opc_veiculo == 6):
                    nome_arq = input("Digite o nome do arquivo json com extensão (.json): ")
                    exportar_arqjson_veiculo(lista_dados, nome_arq)


# Função para a conexão com BD oracle
def conectar_BD():
    # Abrir uma conexão com BD
    try:  # Tentativa de conexão com o BD
        str_dados_serv = orcl.makedsn("oracle.fiap.com.br", "1521", "ORCL")
        str_autentic = orcl.connect(user="RM558962", password="fiap24", dsn=str_dados_serv)

        inst_SQL = str_autentic.cursor()
    except Exception as e:  # Executa o except quando há falha de conexão
        print("Erro: ", e)
        conexao = False
        inst_SQL = ""
        str_autentic = ""
    else:
        conexao = True

    return (conexao, inst_SQL, str_autentic)



def insert_tabela(inst_SQL, str_autentic, str_insert):
    try:
        inst_SQL.execute(str_insert)
        str_autentic.commit()
    except Exception as e:  # executa o except quando há falha de conexão
        print("Erro: ", e)
    else:
        print("Dados inseridos com sucesso")



def update_tabela(inst_SQL, str_autentic, str_update):
    try:
        inst_SQL.execute(str_update)
        str_autentic.commit()
    except Exception as e:  # executa o except quando há falha de conexão
        print("Erro: ", e)
    else:
        print("Dados alterados com sucesso")



def delete_tabela(inst_SQL, str_autentic, str_delete):
    try:
        inst_SQL.execute(str_delete)
        str_autentic.commit()
    except Exception as e:  # executa o except quando há falha de conexão
        print("Erro: ", e)
    else:
        print("Dados excluídos com sucesso")



def consulta_tabela(inst_SQL, str_autentic, str_consulta, colunas):
    lista_dados = []

    inst_SQL.execute(str_consulta)

    dados = inst_SQL.fetchall()

    for dado in dados:
        lista_dados.append(dado)

    lista_dados = sorted(lista_dados)

    dados_df = pd.DataFrame.from_records(lista_dados, columns=colunas, index='ID')

    if (dados_df.empty):
        print("Não há registros na tabela")
    else:
        print(dados_df)
        print("\n")


def exportar_arqjson_usuario(lista_dados, nome_arq):
    try:

        dados_serializaveis = [
            {
                "ID_USUARIO": dado[0],
                "CPF": dado[1],
                "NM_USUARIO": dado[2],
                "EMAIL": dado[3],
                "DT_NASC": dado[4].strftime("%Y-%m-%d") if dado[4] else None,
                "SENHA_LOGIN": dado[5],
                "TELEFONE_USUARIO": dado[6],
                "ENDERECO_USUARIO": dado[7]
            }
            for dado in lista_dados
        ]


        with open(nome_arq, 'w', encoding='utf-8') as f:
            json.dump(dados_serializaveis, f, ensure_ascii=False, indent=4)

        print(f"Dados exportados com sucesso para {nome_arq}")
    except Exception as e:
        print(f"Erro ao exportar para JSON: {e}")


def exportar_arqjson_veiculo(dados, nome_arq):
    try:

        dados_json = [
            {
                "placa": dado[0],
                "marca": dado[2],
                "modelo": dado[3],
                "ano_fabricacao": dado[4],
                "cor": dado[5],
                "km_veiculo": dado[6],
                "tipo_veiculo": dado[7],
                "fk_id_usuario": dado[1]
            }
            for dado in dados
        ]

        with open(nome_arq, "w") as json_file:
            json.dump(dados_json, json_file, indent=4, default=str)

        print(f"Dados exportados para {nome_arq} com sucesso.")

    except Exception as e:
        print("Erro ao exportar para JSON:", e)


if (__name__ == "__main__"):
    main()

